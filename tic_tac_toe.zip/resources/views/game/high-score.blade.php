    <script>
        // 将 updateHighScores 和 updatePagination 移到 ready 函数外部，使其成为全局函数
        let currentPage = 1;

        function updateHighScores(page = 1) {
            $.ajax({
                type: "GET",
                url: `{{ route('game.history') }}?page=${page}`,
                success: function(response) {
                    $('.high').empty();

                    response.data.forEach((score, index) => {
                        const actualIndex = (response.current_page - 1) * 2 + index + 1;
                        const avatarUrl = score.avatar ?
                            `{{ asset('') }}${score.avatar.replace(/\\/g, '')}` :
                            '{{ asset('imgs/default.png') }}';

                        const scoreHtml = `
                        <article class="score">
                            <h4 class="pos" style="background:url(${avatarUrl}) no-repeat center center; background-size: cover">
                                ${actualIndex}
                            </h4>
                            <h4 class="name-high">
                                ${score.username} 
                                <span class="moves">
                                    <span title="玩家步数">${score.player_steps}</span>-<span title="机器人步数">${score.robot_steps}</span>
                                </span>
                            </h4>
                            <p>
                                <span class="date-high">${score.created_at}</span>
                                <span class="time-high">${score.utime} 秒</span>
                            </p>
                        </article>
                    `;
                        $('.high').append(scoreHtml);
                    });

                    // 添加分页控件
                    updatePagination(response.current_page, response.last_page);
                },
                error: function(xhr, status, error) {
                    console.error('获取高分榜时出错:', error);
                }
            });
        }

        function updatePagination(currentPage, lastPage) {
            let paginationHtml = '<div class="pagination">';

            // 上一页按钮
            paginationHtml += `
            <button class="page-btn" ${currentPage <= 1 ? 'disabled' : ''} data-page="${currentPage - 1}">
                <
            </button>
        `;

            // 页码按钮
            for (let i = 1; i <= lastPage; i++) {
                paginationHtml += `
                <button class="page-btn page-number ${i === currentPage ? 'active' : ''}" 
                        data-page="${i}">
                    ${i}
                </button>
            `;
            }

            // 下一页按钮
            paginationHtml += `
            <button class="page-btn" ${currentPage >= lastPage ? 'disabled' : ''} data-page="${currentPage + 1}">
                >
            </button>
        </div>`;

            // 移除旧的分页
            $('.pagination').remove();
            // 添加新的分页
            $('.high').after(paginationHtml);

            // 绑定点击事件
            $('.pagination .page-btn').not('[disabled]').on('click', function() {
                const page = $(this).data('page');
                updateHighScores(page);
            });
        }

        $(document).ready(function() {
            updateHighScores();
            let currentPlayer = Math.random() < 0.5 ? 'o' : 'x'; // 随机决定谁先开始
            let playerSteps = 0; // 玩家步数计数器
            let robotSteps = 0; // AI步数计数器
            let isGameOver = false; // 游戏结束标志
            let playerMarker = 'o';
            let robotMarker = 'x';
            let time = 0;
            let timer;

            // 开始计时
            function startTimer() {
                timer = setInterval(function() {
                    time++;
                    $('.time').text(time + " 秒");
                }, 1000);
            }

            // 停止计时
            function stopTimer() {
                clearInterval(timer);
            }
            // 初始化游戏
            function initGame() {
                time = 0;
                $('.time').text("0 秒");
                startTimer(); // 开始计时
            }

            // 设置初始状态
            initGame();

            // 高亮显示开始的玩家
            if (currentPlayer === 'o') {
                $('.circle.o').addClass('highlight');
            } else {
                $('.circle.x').addClass('highlight');
                // 如果AI先开始，进行第一次移动
                setTimeout(robotMove, 500);
            }

            // 玩家下子
            $('.img_tic').on('click', function() {
                if (!isGameOver && $(this).css('background-image') === 'none' && currentPlayer ===
                    playerMarker) {
                    $(this).css('background-image', 'url(imgs/' + playerMarker + '.png)');
                    playerSteps++;
                    $('.usermoves').text(playerSteps);

                    if (checkWinner(playerMarker)) {
                        $('.game-alert').text('恭喜你赢了！').show();
                        isGameOver = true;
                        stopTimer(); // 游戏结束

                        console.log(`玩家步数: ${playerSteps}, 机器人步数: ${robotSteps}, 用时: ${time} 秒`);
                        $.ajax({
                            type: "POST",
                            url: "{{ route('game.save') }}",
                            data: {
                                player_moves: playerSteps,
                                robot_moves: robotSteps,
                                time_taken: time,
                                _token: "{{ csrf_token() }}"
                            },
                            success: function(response) {
                                updateHighScores();
                                console.log('游戏记录保存成功！');
                            },
                            error: function(xhr, status, error) {
                                console.error('保存游戏记录时出错:', error);
                            }
                        });
                    }

                    if (checkDraw()) {
                        $('.game-alert').text('平局！').show();
                        isGameOver = true;
                        stopTimer(); // 游戏结束
                        return;
                    }

                    // 移动后切换玩家
                    currentPlayer = robotMarker;
                    updateTurnHighlight();
                    setTimeout(robotMove, 500);
                }
            });

            function updatePagination(currentPage, lastPage) {
                const paginationHtml = `
        <div class="pagination">
            <button class="page-btn prev-btn">上一页</button>
            <span class="page-info">${currentPage} / ${lastPage}</span>
            <button class="page-btn next-btn">下一页</button>
        </div>
    `;

                // 移除旧的分页
                $('.pagination').remove();
                // 添加新的分页
                $('.high').after(paginationHtml);

                // 绑定点击事件
                $('.pagination .page-btn').not('[disabled]').on('click', function() {
                    const page = $(this).data('page');
                    updateHighScores(page);
                });
            }

            function robotMove() {
                if (isGameOver) return;

                let emptyFields = [];

                // 找到所有空的单元格
                $('.img_tic').each(function() {
                    if ($(this).css('background-image') === 'none') {
                        emptyFields.push($(this));
                    }
                });

                // 如果有空的单元格，随机选择一个作为AI的移动
                if (emptyFields.length > 0) {
                    let randomIndex = Math.floor(Math.random() * emptyFields.length);
                    $(emptyFields[randomIndex]).css('background-image', 'url(imgs/' + robotMarker + '.png)');

                    robotSteps++;
                    $('.computermoves').text(robotSteps);

                    if (checkWinner(robotMarker)) {
                        $('.game-alert').text('很遗憾，机器人赢了！').show();
                        isGameOver = true;
                        stopTimer(); // 游戏结束
                        return;
                    }

                    if (checkDraw()) {
                        $('.game-alert').text('平局！').show();
                        isGameOver = true;
                        stopTimer(); // 游戏结束
                        return;
                    }
                }

                // 切换回人类玩家
                currentPlayer = playerMarker;
                updateTurnHighlight();
            }

            // 更新高亮显示的回合指示器
            function updateTurnHighlight() {
                if (currentPlayer === playerMarker) {
                    $('.circle.o').addClass('highlight');
                    $('.circle.x').removeClass('highlight');
                } else {
                    $('.circle.x').addClass('highlight');
                    $('.circle.o').removeClass('highlight');
                }
            }

            function checkWinner(player) {
                const winPatterns = [
                    [0, 1, 2],
                    [3, 4, 5],
                    [6, 7, 8], // 行
                    [0, 3, 6],
                    [1, 4, 7],
                    [2, 5, 8], // 列
                    [0, 4, 8],
                    [2, 4, 6] // 对角线
                ];

                const playerImg = `imgs/${player}.png`; // 用于比较的精确路径
                const cells = $('.img_tic').map((_, el) => $(el).css('background-image')).get();

                return winPatterns.some(pattern => {
                    return pattern.every(index => cells[index] && cells[index].includes(playerImg));
                });
            }

            function checkDraw() {
                return $('.img_tic').filter((_, el) => $(el).css('background-image') === 'none').length === 0;
            }

        });
    </script>