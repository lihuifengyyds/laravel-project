<?php
session_start();

$operation=$_POST['operation'];

if($operation==='init'){//初始化操作

    $_SESSION['start_time']=time();//游戏开始时间
    $_SESSION['chess_board']=['1'=>0,'2'=>0,'3'=>0,'4'=>0,'5'=>0,'6'=>0,'7'=>0,'8'=>0,'9'=>0];

}else{//下子和判断输赢
    
    //游戏尚未结束code=-1   玩家胜利:code=1  机器人胜利：code=2  平局：code=0  数据库连接错误：code=-2 数据库插入失败：code=-3 
    $result=[];

    $role=(int)$_POST['role'];//前端发送过来的角色编号 1：玩家  2：机器人
    $position=$_POST['position'];//前端发送过来的棋盘位置

    $_SESSION['chess_board'][$position]=$role;//设置棋盘  下子

    //判断胜负 
    //胜利的八种棋盘编号：123  456  789  147  258  369  159  357

    //1、判断玩家是否胜利
    if(($_SESSION['chess_board']['1']==1&&$_SESSION['chess_board']['2']==1&&$_SESSION['chess_board']['3']==1)||
        ($_SESSION['chess_board']['4']==1&&$_SESSION['chess_board']['5']==1&&$_SESSION['chess_board']['6']==1)||
        ($_SESSION['chess_board']['7']==1&&$_SESSION['chess_board']['8']==1&&$_SESSION['chess_board']['9']==1)||
        ($_SESSION['chess_board']['1']==1&&$_SESSION['chess_board']['4']==1&&$_SESSION['chess_board']['7']==1)||
        ($_SESSION['chess_board']['2']==1&&$_SESSION['chess_board']['5']==1&&$_SESSION['chess_board']['8']==1)||
        ($_SESSION['chess_board']['3']==1&&$_SESSION['chess_board']['6']==1&&$_SESSION['chess_board']['9']==1)||
        ($_SESSION['chess_board']['1']==1&&$_SESSION['chess_board']['5']==1&&$_SESSION['chess_board']['9']==1)||
        ($_SESSION['chess_board']['3']==1&&$_SESSION['chess_board']['5']==1&&$_SESSION['chess_board']['7']==1)){
            $time = time() - $_SESSION['start_time'];//计算游戏用时
            //计算玩家和机器人步数
            $p_steps=0;
            $r_steps=0;
            foreach($_SESSION['chess_board'] as $p){//遍历棋盘，统计玩家和机器人的步数
                if($p==1) $p_steps++;
                if($p==2) $r_steps++;
            }
            //插入数据库
            insertRecord($p_steps,$r_steps,$time);
            //返回结果到前端
            $result=['code'=>1,'msg'=>'玩家胜利！','chess_board'=>$_SESSION['chess_board'],'time'=>$time];
            echo json_encode($result);
            exit();
    }

    //2、判断机器人是否胜利
    if(($_SESSION['chess_board']['1']==2&&$_SESSION['chess_board']['2']==2&&$_SESSION['chess_board']['3']==2)||
        ($_SESSION['chess_board']['4']==2&&$_SESSION['chess_board']['5']==2&&$_SESSION['chess_board']['6']==2)||
        ($_SESSION['chess_board']['7']==2&&$_SESSION['chess_board']['8']==2&&$_SESSION['chess_board']['9']==2)||
        ($_SESSION['chess_board']['1']==2&&$_SESSION['chess_board']['4']==2&&$_SESSION['chess_board']['7']==2)||
        ($_SESSION['chess_board']['2']==2&&$_SESSION['chess_board']['5']==2&&$_SESSION['chess_board']['8']==2)||
        ($_SESSION['chess_board']['3']==2&&$_SESSION['chess_board']['6']==2&&$_SESSION['chess_board']['9']==2)||
        ($_SESSION['chess_board']['1']==2&&$_SESSION['chess_board']['5']==2&&$_SESSION['chess_board']['9']==2)||
        ($_SESSION['chess_board']['3']==2&&$_SESSION['chess_board']['5']==2&&$_SESSION['chess_board']['7']==2)){
            $time = time() - $_SESSION['start_time'];//计算游戏用时
            $result=['code'=>2,'msg'=>'玩家失败！','chess_board'=>$_SESSION['chess_board'],'time'=>$time];
            echo json_encode($result);
            exit();
    }

    //3、判断是否平局
    $hasEmpty=false;//标记是否存在空格子
    foreach($_SESSION['chess_board'] as $p){
        if($p==0){
            $hasEmpty=true;//存在空格子
            break;
        }
    }
    if($hasEmpty==false){//不存在空格子，说明平局
        $time = time() - $_SESSION['start_time'];//计算游戏用时
        $result=['code'=>0,'msg'=>'平起平坐！','chess_board'=>$_SESSION['chess_board'],'time'=>$time];
        echo json_encode($result);
        exit();
    }


    //4、未分胜负
    $time = time() - $_SESSION['start_time'];//计算游戏用时
    $result=['code'=>-1,'msg'=>'','chess_board'=>$_SESSION['chess_board'],'time'=>$time];
    echo json_encode($result);

}


//插入数据库函数
function insertRecord($p_steps,$r_steps,$game_time){
    $severname='localhost';//127.0.0.1:3306
    $db_username='root';
    $db_password='root';
    $dbname='tic_tac_toe';
    //1.创建连接
    $conn=mysqli_connect($severname,$db_username,$db_password,$dbname);
    //2.检查连接
    if(!$conn){
        $result=['code'=>-2,'msg'=>'数据库连接失败！','chess_board'=>$_SESSION['chess_board'],'time'=>$game_time];
        echo json_encode($result);
        exit();
    }
    //3.执行语句
    $sql="insert into records(user_id,p_steps,r_steps,game_time,created_time) values({$_SESSION['userinfo']['id']},{$p_steps},{$r_steps},{$game_time},".time().")";
    $query_result = mysqli_query($conn,$sql);
    if(!$query_result){//插入失败
        $result=['code'=>-3,'msg'=>'数据库插入失败！','chess_board'=>$_SESSION['chess_board'],'time'=>$game_time];
        echo json_encode($result);
        exit();
    }
    //4.关闭连接
    mysqli_close($conn);
}


?>