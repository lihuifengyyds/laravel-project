# laravel-lang-zh_cn
laravel 中文包

修改文件 config/app.php
'locale' => 'zh_cn'

把当前的文件 下载到
resources/lang/zh_cn/
