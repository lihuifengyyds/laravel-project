<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Session;
class UserCenter
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(!Session::get('userinfo')){
            return redirect('/login');
        }

        // 获取会话中的密码
        $current_password = Session::get('userinfo')->password;
        
        // 验证所有字段
        $request->validate([
            'current_password' => 'required',
            'new_password' => 'required|min:6|max:10|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{6,10}$/',
            'new_password_confirm' => 'required|same:new_password',
            'email' => 'email',
            'avatar' => 'required|file|mimes:jpeg,png|min:10|max:500'
        ],[
            'current_password.required' => '请输入原密码',
            'new_password.required' => '请输入新密码',
            'new_password.min' => '新密码长度至少为6位',
            'new_password.max' => '新密码长度最多为10位',
            'new_password.regex' => '新密码必须包含大小写字母和数字',
            'new_password_confirm.required' => '请输入确认密码',
            'new_password_confirm.same' => '两次输入的密码不一致',
            'email.email' => '请输入正确的邮箱格式',
            'avatar.required' => '请选择头像',
            'avatar.file' => '请选择头像',
            'avatar.mimes' => '请选择jpeg或png格式的头像',
            'avatar.min' => '头像大小至少为10KB',
            'avatar.max' => '头像大小最多为500KB'
        ]);

        // 验证原密码是否匹配
        if(md5($request->input('current_password')) != $current_password) {
            return redirect()->back()->withErrors(['current_password' => '原密码错误']);
        }

        return $next($request);
    }
}
