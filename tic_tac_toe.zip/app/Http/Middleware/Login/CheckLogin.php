<?php

namespace App\Http\Middleware\Login;

use Closure;

class CheckLogin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $request->validate([
            'username' => 'required',
            'password' => 'required',
        ]);
        return $next($request);
    }
}
