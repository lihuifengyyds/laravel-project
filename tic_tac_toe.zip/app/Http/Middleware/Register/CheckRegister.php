<?php

namespace App\Http\Middleware\Register;

use Closure;
use Illuminate\Support\Facades\Validator;

class CheckRegister
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $message = [
            'username.unique' => '该用户已被注册.',
        ];
        $validator = Validator::make($request->all(),[
            'username' => 'required|min:3|max:15|unique:users',
            'password' => [
                'required',
                'min:6',
                'max:10',
                'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{6,10}$/'
            ],
            'email' => 'email',
            'avatar' => 'required|file|mimes:jpeg,png|min:10|max:500'
        ],$message);

        if($validator->fails()){
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }
        return $next($request);
    }
}
