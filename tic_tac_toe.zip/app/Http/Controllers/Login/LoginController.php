<?php

namespace App\Http\Controllers\Login;

use App\Home\Users;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    //
    public function show(){
        return view('login.login');
    }

    public function postLogin(Request $request){
        $users = new Users();
        $username = $request->input('username');
        $password = $request->input('password');
        $users = $users->where('username',$request->input('username'))->where('password',md5($request->input('password')))->first();

        if($users && md5($password) === $users->password){
            session()->put('userinfo',$users);
            return redirect('/home');
        }else{
            session()->flash('error','用户名或密码错误');
            return redirect()->back();
        }
    }

    //退出登录
    public function logout(Request $request){
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/login');
    }
}
