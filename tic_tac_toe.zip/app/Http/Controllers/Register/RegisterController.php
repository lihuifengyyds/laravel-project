<?php

namespace App\Http\Controllers\Register;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Home\Users;
// use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    public function show()
    {
        return view('register.register');
    }

    public function postRegister(Request $request)
    {
        // 验证请求数据
        // $validated = $request->validate([
        //     'username' => 'required|unique:users|max:255',
        //     'email' => 'required|email|unique:users',
        //     'password' => 'required|min:6',
        //     'avatar' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
        //     'validcode' => 'required'
        // ]);

        $users = new Users();
        $avatar = $request->file('avatar');
        
        $users->username = $request->input('username');
        // 使用Hash替代不安全的md5
        $users->password = md5($request->input('password'));
        $users->email = $request->input('email');

        // 处理图片上传
        if ($avatar) {
            $fileName = time() . '.' . $avatar->getClientOriginalExtension();
            $avatar->move(public_path('images'), $fileName);
            $users->avatar = 'images/' . $fileName;
        }

        $users->save();
        
        return redirect('/login')->with('success', '注册成功！');
    }
}
