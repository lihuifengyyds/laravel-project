<?php

namespace App\Http\Controllers\Home;

use App\Home\Users as HomeUsers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Home\Users;
use Illuminate\Support\Facades\Session;

class UserCenterController extends Controller
{
    //
    public function show()
    {
        $users = Session::get('userinfo');
        return view('home.user-center',compact('users'));
    }

    public function updateProfile(Request $request)
    {
        $user = Users::find(Session::get('userinfo')->id);
        if(!$user){
            return redirect()->back()->with('error','用户未找到');
        }

        //跟新邮箱
        $user->email = $request->input('email');
        if($request->filled('new_password')){
            $user->password = md5($request->input('new_password'));
        }

        //处理头像上传
        if ($request->hasFile('avatar')) {
            $avatar = $request->file('avatar');
            $destinationPath = public_path('/images');
            $fileName = time().'.'.$avatar->getClientOriginalExtension();
            $avatar->move($destinationPath,$fileName);
            
            $user->avatar = 'images/' . $fileName;
        }

        $user->updated_at = now();
        $user->save();

        Session::put('userinfo',$user);
        return redirect('/login')->with('success','用户中心个更新成功');
    }
}
