<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Home\Users;

class HomeController extends Controller
{
    //

    public function show(){
        $users = session('userinfo');
        return view('home.main',compact('users'));
    }

    // public function main2(){
    //     return view('home.main2');
    // }
    public function updateAvatar(Request $request)
    {
        $users = session()->get('userinfo');
        $userId = $users['id'];
    }
}
