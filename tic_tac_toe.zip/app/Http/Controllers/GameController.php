<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Home\Rank;
use Illuminate\Support\Facades\DB;
use App\Home\User;
use Illuminate\Support\Facades\Auth;
// use Illuminate\Support\Facades\Auth;
class GameController extends Controller
{
    public function saveGame(Request $request)
    {
        // 获取当前登录用户的 ID

        // 继续您的保存逻辑
        $result = new Rank;
        $userId = Session::get('userinfo')->id;
        $result->userid = $userId; // 这里使用获取到的用户 ID
        $result->player_steps = $request->input('player_moves');
        $result->robot_steps = $request->input('robot_moves');
        $result->utime = $request->input('time_taken');
        $result->save();

        return response()->json(['message' => 'Game saved successfully']);
    }

    public function showHistory()
    {
        $scores = Rank::select(
            'users.username',
            'users.avatar',
            'rank.player_steps',
            'rank.robot_steps',
            'rank.utime',
            'rank.created_at'  // 添加 created_at 字段
        )
            ->join('users', 'rank.userid', '=', 'users.id')
            ->whereIn('rank.id', function ($query) {
                $query->select(DB::raw('MAX(id)'))
                    ->from('rank')
                    ->groupBy('userid');
            })
            ->orderBy('rank.player_steps', 'asc')
            ->orderBy('rank.utime', 'asc')
            ->paginate(3);

        return response()->json([
            'data' => collect($scores->items())->map(function ($score) {
                return [
                    'username' => $score->username,
                    'avatar' => $score->avatar,
                    'player_steps' => $score->player_steps,
                    'robot_steps' => $score->robot_steps,
                    'utime' => $score->utime,
                    'created_at' => date('Y-m-d', strtotime($score->created_at))  // 格式化日期
                ];
            }),
            'current_page' => $scores->currentPage(),
            'last_page' => $scores->lastPage(),
            'total' => $scores->total()
        ]);
    }
}
