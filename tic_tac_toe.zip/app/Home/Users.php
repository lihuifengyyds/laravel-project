<?php

namespace App\Home;

use Illuminate\Database\Eloquent\Model;

class Users extends Model
{
    protected $table = 'users';
    //定义主键
    protected $primaryKey = 'id';
    public $timestamps = true;

    protected $dateFormat = "U";

    protected $fillable = ['id','username','password','email','avatar'];

}
