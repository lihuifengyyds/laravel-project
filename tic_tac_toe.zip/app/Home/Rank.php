<?php

namespace App\Home;

use Illuminate\Database\Eloquent\Model;

class Rank extends Model
{
    protected $table = 'rank';
    //定义主键
    protected $primaryKey = 'id';
    public $timestamps = true;

    protected $dateFormat = "U";

    protected $fillable = ['userid','player_steps,robot_steps,utime'];

    public function user(){
        return $this->belongsTo('App\Home\User','userid');
    }
    // protected $casts = [
    //     'created_at' => 'datetime:Y-m-d',  // 指定日期格式
    // ];
}
