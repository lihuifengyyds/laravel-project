<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use Illuminate\Support\Facades\Route;

// 首页路由
Route::get('/', function () {
    return view('welcome');
});

// 用户注册相关路由
Route::get('/register','Register\RegisterController@show');                                    // 显示注册页面
Route::post('/register','Register\RegisterController@postRegister')->middleware('checkRegister'); // 处理注册请求

// 用户登录相关路由
Route::get('/login','Login\LoginController@show');                                            // 显示登录页面
Route::post('/login','Login\LoginController@postLogin')->middleware('checkLogin');             // 处理登录请求
Route::post('/logout','Login\LoginController@logout')->name('logout');                         // 处理登出请求

// 用户主页相关路由
Route::get('/home','Home\HomeController@show')->middleware('home');                           // 显示用户主页
Route::post('/update-avatar','Home\HomeController@updateAvatar')->name('update.avatar');      // 更新用户头像

// 用户中心相关路由
Route::get('/user-center','Home\UserCenterController@show')->name('user.center');             // 显示用户中心
Route::post('/update-profile', 'Home\UserCenterController@updateProfile')->middleware('userCenter'); // 更新用户资料
Route::get('/update-profile', 'Home\UserCenterController@updateProfile')->middleware('userCenter');  // 显示更新资料页面

// 游戏相关路由
Route::post('/game/save', 'GameController@saveGame')->name('game.save');                      // 保存游戏进度
Route::get('/game/history', 'GameController@showHistory')->name('game.history');              // 显示游戏历史记录