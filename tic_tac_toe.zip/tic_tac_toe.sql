-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2024-11-27 10:06:13
-- 服务器版本： 5.7.26
-- PHP 版本： 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `tic_tac_toe`
--

-- --------------------------------------------------------

--
-- 表的结构 `rank`
--

CREATE TABLE `rank` (
  `id` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `player_steps` int(11) NOT NULL,
  `robot_steps` int(11) NOT NULL,
  `utime` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `rank`
--

INSERT INTO `rank` (`id`, `userid`, `player_steps`, `robot_steps`, `utime`, `created_at`, `updated_at`) VALUES
(6, 5, 3, 3, 4, 1731374536, 1731374536),
(7, 5, 3, 3, 4, 1731413026, 1731413026),
(8, 5, 3, 2, 5, 1731413761, 1731413761),
(9, 5, 3, 3, 3, 1731415220, 1731415220),
(10, 5, 4, 4, 5, 1731415578, 1731415578),
(11, 5, 3, 2, 11, 1731415941, 1731415941),
(12, 5, 3, 2, 2, 1731416050, 1731416050),
(13, 5, 3, 2, 35, 1731420522, 1731420522),
(14, 5, 3, 3, 3, 1731421114, 1731421114),
(15, 3, 3, 2, 4, 1731423383, 1731423383),
(16, 6, 3, 3, 4, 1731423448, 1731423448),
(17, 6, 3, 3, 3, 1731423569, 1731423569),
(18, 6, 3, 2, 5, 1731423587, 1731423587),
(19, 6, 3, 3, 3, 1731423595, 1731423595),
(20, 7, 3, 3, 6, 1731423801, 1731423801),
(21, 7, 3, 3, 5, 1731423941, 1731423941),
(22, 5, 4, 4, 5, 1731496305, 1731496305),
(23, 5, 3, 3, 3, 1731496324, 1731496324),
(24, 5, 3, 2, 3, 1731641729, 1731641729),
(25, 5, 3, 2, 2, 1731763619, 1731763619),
(26, 5, 3, 3, 5, 1731763626, 1731763626),
(27, 9, 3, 2, 5, 1732069200, 1732069200),
(28, 9, 4, 3, 6, 1732069212, 1732069212),
(29, 9, 4, 4, 2, 1732069222, 1732069222),
(30, 5, 3, 2, 4, 1732670626, 1732670626),
(31, 5, 3, 3, 4, 1732671877, 1732671877),
(32, 5, 3, 2, 7, 1732671894, 1732671894),
(33, 5, 3, 3, 4, 1732671943, 1732671943);

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `avatar`, `created_at`, `updated_at`) VALUES
(3, 'Zjunhao6', '92bf281b29813c597ba20832a71dc089', 'lihuifeng595@gmail.com', 'images/1730861287.jpg', 1730861287, 1730861287),
(4, 'Xiaoli456', '92bf281b29813c597ba20832a71dc089', 'lihuifeng595@gmail.com', 'images/1731075687.jpg', 1731075687, 1731075687),
(5, 'Lwenyan1', '92bf281b29813c597ba20832a71dc089', 'lihuifeng595@2925.com', 'images/1731638086.jpg', 1731161848, 1731638086),
(6, 'lihuifeng6', 'b41cb62ec6767f2e41f9df7a2d161515', 'lihuifeng595@2925.com', 'images/1731637767.png', 1731423434, 1731637767),
(7, 'lihuifeng7', '92bf281b29813c597ba20832a71dc089', 'lihuifeng595@gmail.com', 'images/1731423787.jpg', 1731423787, 1731423787),
(9, 'zangjunhao', '92bf281b29813c597ba20832a71dc089', 'lihuifeng595@gmail.com', 'images/1732073059.jpg', 1732069185, 1732073059);

--
-- 转储表的索引
--

--
-- 表的索引 `rank`
--
ALTER TABLE `rank`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`);

--
-- 表的索引 `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `rank`
--
ALTER TABLE `rank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- 使用表AUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 限制导出的表
--

--
-- 限制表 `rank`
--
ALTER TABLE `rank`
  ADD CONSTRAINT `rank_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
