<!DOCTYPE html>
<html>
<head>
    <title>游戏历史记录</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <h1>游戏历史记录</h1>
    
    <table>
        <thead>
            <tr>
                <th>玩家名称</th>
                <th>玩家步数</th>
                <th>机器人步数</th>
                <th>用时</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($score->name); ?></td>
                <td><?php echo e($score->player_steps); ?></td>
                <td><?php echo e($score->robot_steps); ?></td>
                <td><?php echo e($score->utime); ?> 秒</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<html>
<head>
    <title>游戏历史记录</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <h1>游戏历史记录</h1>
    
    <table>
        <thead>
            <tr>
                <th>玩家名称</th>
                <th>玩家步数</th>
                <th>机器人步数</th>
                <th>用时</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($score->name); ?></td>
                <td><?php echo e($score->player_steps); ?></td>
                <td><?php echo e($score->robot_steps); ?></td>
                <td><?php echo e($score->utime); ?> 秒</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>