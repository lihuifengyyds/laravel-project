<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>井字过三关</title>
    <link rel="stylesheet" href="css/style.css">
    <style type="text/css">
        /* style for user image (overwrite .o) */
    </style>
    <!-- put any js-code into this file -->

    <script src="js/jquery-2.1.1.min.js"></script>
    <!--<script src="js/app.js"></script>-->
</head>
<style>
    .status {
        display: flex;
        align-items: center;
        /* 垂直方向居中 */
        justify-content: flex-end;
        /* 水平方向靠右 */
    }

    .user-photo {
        width: 50px;
        /* 头像的宽度 */
        height: 50px;
        /* 头像的高度 */
        background-size: cover;
        /* 确保背景图片覆盖整个圆形 */
        border-radius: 50%;
        /* 圆形头像 */
        margin-right: 10px;
        /* 头像和按钮之间的间距 */
    }

    form input,
    button {
        width: 60px;
    }

    .highlight {
        border: 8px solid red;
    }

    .pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 15px;
        gap: 5px;
        /* 减小按钮之间的间距 */
    }

    .page-btn {
        padding: 3px 8px;
        /* 减小内边距 */
        border: none;
        border-radius: 3px;
        /* 减小圆角 */
        background: #4a4a4a;
        color: white;
        cursor: pointer;
        width: auto !important;
        min-width: 30px;
        /* 设置最小宽度 */
        font-size: 12px;
        /* 减小字体大小 */
        line-height: 1.5;
    }

    .page-btn:disabled {
        background: #2a2a2a;
        cursor: not-allowed;
        opacity: 0.5;
    }

    .page-btn:hover:not(:disabled) {
        background: #5a5a5a;
    }

    .page-info {
        color: #888;
        padding: 0 8px;
        font-size: 12px;
        /* 减小页码信息的字体大小 */
    }

    .page-number {
        padding: 3px 8px;
    }

    .page-btn.active {
        background: #007bff;
    }
</style>

<body>



    </section>
    <section class="container-game">
        <article class="title-row">
            <article class="title">
                <h1>井字过三关</h1>
            </article>
            <article class="status">
                
                <form action="<?php echo e(route('logout')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <button class="right" type="submit" style="background:none;color:#fff;">退出</button>
                </form>
            </article>
        </article>
        <article class="row initial-page">
            <article class="col">
                <article class="subtitle-row">
                    <h2>游戏规则</h2>
                </article>
                <article class="container-row">
                    <ul>
                        <li>先注册并登录游戏</li>
                        <li>与机器人轮流在印有九格方盘上下 “X” 或 “O”</li>
                        <li>谁先把三个同一记号排成横线、直线、斜线， 即是胜者</li>
                    </ul>
                </article>
                <article class="subtitle-row">
                    <h2>高分榜</h2>
                </article>
                <article class="container-row high">
                    
                </article>
            </article>
            <!--游戏界面-->
            <article class="col border-line col-game-spacing" id="game_play">

                <article class="subtitle-row">
                    <h2>游戏开始</h2>
                    <article class="alert-spacing">
                        <!--article class="alert game-alert">恭喜胜利!!</article-->
                    </article>
                    <figure class="container-photo circle o"></figure>
                    <figure class="container-photo circle x"></figure>
                    <p class="dates">用时: <span class="time">0 秒</span></p>
                    <h3 class="relative-pos-game">
                        <span class="points"><span class="nameuser">玩家: <span
                                    class="usermoves moves">3</span></span></span><span class="points"><span
                                class="computer">机器人: <span class="computermoves moves">2</span></span></span>
                    </h3>
                </article>
                <article class="container-row relative-pos-game">
                    <article class="game">
                        <article class="field"><button id="1" class="btn img_tic"
                                onclick="userStep(this)"></button></article>
                        <article class="field"><button id="2" class="btn img_tic"
                                onclick="userStep(this)"></button></article>
                        <article class="field"><button id="3" class="btn img_tic"
                                onclick="userStep(this)"></button></article>
                        <article class="field"><button id="4" class="btn img_tic"
                                onclick="userStep(this)"></button></article>
                        <article class="field"><button id="5" class="btn img_tic"
                                onclick="userStep(this)"></button></article>
                        <article class="field"><button id="6" class="btn img_tic"
                                onclick="userStep(this)"></button></article>
                        <article class="field"><button id="7" class="btn img_tic"
                                onclick="userStep(this)"></button></article>
                        <article class="field"><button id="8" class="btn img_tic"
                                onclick="userStep(this)"></button></article>
                        <article class="field"><button id="9" class="btn img_tic"
                                onclick="userStep(this)"></button></article>
                    </article>
                </article>

                <div class="button-start">
                    <button onclick="init()">再玩一次</button>
                </div>
    </section>

    <script>
        var time = 0; //游戏用时
        var usermoves = 0; //玩家步数
        var computermoves = 0; //机器人步数
        var gameInterval = null; //计时器
        var stepFlag = 'user'; //标记用户或者机器人在下子
        var isGameOver = false;
        $(function() {
            init(); //页面数据初始化

        });

        //游戏数据初始化
        function init() {
            time = 0;
            usermoves = 0;
            computermoves = 0;
            stepFlag = 'user';
            isGameOver = false;

            //将游戏数据显示到页面
            $('.alert-spacing').html('');
            $('.time').html('0 秒');
            $('.usermoves').html(usermoves);
            $('.computermoves').html(computermoves);

            //棋盘清空
            $('.img_tic').removeClass('o').removeClass('x');

            if (gameInterval) {
                clearInterval(gameInterval);
            }

            gameInterval = setInterval(function() {
                time++;
                $('.time').html(time + ' 秒');
            }, 1000);
            //让后端初始化游戏数据：棋盘数据和用时
            // $.post('./include/game.php', {
            //     'operation': 'init'
            // }, function(data) {
            //     clearInterval(gameInterval); //将上一局游戏的计时器线程清掉
            //     //开始计时
            //     gameInterval = setInterval(function() {
            //         $('.time').html((++time) + ' 秒');
            //     }, 1000);
            // });
        }

        //玩家下子
        function userStep(obj) {
            if (stepFlag != 'user') return;

            if ($(obj).hasClass('o') || $(obj).hasClass('x')) return; //排除以下子的宫格  如果这个宫格已被下子，则直接忽略点击

            //玩家下子
            $('.usermoves').html(++usermoves);
            $(obj).addClass('o');
            stepFlag = 'ai';
            //发送位置数据
            sendStepData(1, $(obj).attr('id')); //$(obj).attr('id') 获取id属性值   玩家下子：1   机器人下子：2
            //机器人下子
            if (isGameOver != true) {
                setTimeout(function() {
                    aiStep();
                }, 1500);
            }

        }

        //机器人下子
        function aiStep() {
            if (stepFlag != 'ai') return;

            if ((usermoves + computermoves) == 9) return; //判断棋盘是否以下满

            var rand = Math.floor(Math.random() * 9 + 1); //1-9 随机获取下子位置
            console.log(rand);

            if ($('#' + rand).hasClass('o') || $('#' + rand).hasClass('x')) { //排除以下子的宫格  如果这个宫格已被下子，则直接忽略
                aiStep(); //函数递归
                return;
            }

            //下子
            $('.computermoves').html(++computermoves);
            $('#' + rand).addClass('x');
            stepFlag = 'user';
            //发送位置数据
            sendStepData(2, rand); //玩家下子：1   机器人下子：2
            return;

        }

        //提交游戏数据
        function sendStepData(role, position) {
            $.ajaxSettings.async = false;
            $.ajax({
                url: '<?php echo e(route('game')); ?>',
                type: 'POST',
                data: {
                    '_token': '<?php echo e(csrf_token()); ?>',
                    'role': role,
                    'position': position
                },
                success: function(data) {
                    // 添加数据检查
                    console.log('Response data:', data); // 调试用
                    
                    if (!data) {
                        console.error('No data received');
                        return;
                    }
                    
                    // 检查数据是否为字符串（需要解析）
                    if (typeof data === 'string') {
                        try {
                            data = JSON.parse(data);
                        } catch (e) {
                            console.error('Failed to parse response:', e);
                            return;
                        }
                    }
                    
                    // 使用可选链操作符来安全访问属性
                    if (data?.code !== -1) {
                        isGameOver = true;
                        clearInterval(gameInterval);
                        if (data?.time !== undefined) {
                            $('.time').html(data.time + ' 秒');
                        }
                        if (data?.msg) {
                            $('.alert-spacing').html('<article class="alert game-alert">' + data.msg + '</article>');
                        }
                    }
                },
                error: function(xhr, status, error) {
                    // 添加错误处理
                    console.error('Ajax error:', status, error);
                }
            });
            $.ajaxSettings.async = true;
        }
    </script>

</body>

</html>
