<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>井字过三关——登录</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .status {
            display: flex;
            align-items: center; /* 垂直方向居中 */
            justify-content: flex-end; /* 水平方向靠右 */
        }
    
    
        .highlight{
            border:8px solid red;
        }
    
        .pagination {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 15px;
        gap: 5px; /* 减小按钮之间的间距 */
    }
    
    .page-btn {
        padding: 3px 8px; /* 减小内边距 */
        border: none;
        border-radius: 3px; /* 减小圆角 */
        background: #4a4a4a;
        color: white;
        cursor: pointer;
        width: auto !important;
        min-width: 30px; /* 设置最小宽度 */
        font-size: 12px; /* 减小字体大小 */
        line-height: 1.5;
    }
    
    .page-btn:disabled {
        background: #2a2a2a;
        cursor: not-allowed;
        opacity: 0.5;
    }
    
    .page-btn:hover:not(:disabled) {
        background: #5a5a5a;
    }
    
    .page-info {
        color: #888;
        padding: 0 8px;
        font-size: 12px; /* 减小页码信息的字体大小 */
    }
    
    .page-number {
        padding: 3px 8px;
    }
    
    .page-btn.active {
        background: #007bff;
    }
    </style>
    <!-- put any js-code into this file -->

    <script src="js/jquery-2.1.1.min.js"></script>
</head>
<body>



</section>
<section class="container-game">
    <article class="title-row">
        <article class="title">
            <h1>井字过三关</h1>
        </article>




    </article>
    <article class="row initial-page">
        <article class="col">
            <article class="subtitle-row">
                <h2>游戏规则</h2>
            </article>
            <article class="container-row">
                <ul>
                    <li>先注册并登录游戏</li>
                    <li>与机器人轮流在印有九格方盘上下 “X” 或 “O”</li>
                    <li>谁先把三个同一记号排成横线、直线、斜线， 即是胜者</li>
                </ul>
            </article>
            <article class="subtitle-row">
                <h2>高分榜</h2>
            </article>
            <article class="container-row high">
                
            </article>
        </article>
        <!--登录界面-->
        <article class="col border-line col-game-spacing">
            <article class="subtitle-row">
                <h2>玩家登录</h2>
            </article>
            <article class="container-row form">
                <form class="form-content" action="/login" method="post">
                    <?php echo e(csrf_field()); ?>

                    <label for="username">输入用户名</label>
                    <input id="username" type="text" name="username"><br>

                    <label for="password">输入密码</label>
                    <input id="password" type="text" name="password"><br>

                    <input style="background:rgba(52, 152, 219,1);color:#fff;" type="submit" value="开始游戏">
                </form>
                <article class="alert-spacing-error">
                    <?php if($errors->all()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert">
                                <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </article>
            </article>
        </article>
        <!--登录界面-->

</section>
<script>
            // 将 updateHighScores 和 updatePagination 移到 ready 函数外部，使其成为全局函数
        let currentPage = 1;

        function updateHighScores(page = 1) {
        $.ajax({
            type: "GET", 
            url: `<?php echo e(route('game.history')); ?>?page=${page}`,
            success: function(response) {
                $('.high').empty();
                
                response.data.forEach((score, index) => {
                    const actualIndex = (response.current_page - 1) * 2 + index + 1;
                    const avatarUrl = score.avatar 
                        ? `<?php echo e(asset('')); ?>${score.avatar.replace(/\\/g, '')}`
                        : '<?php echo e(asset("imgs/default.png")); ?>';
                    
                    const scoreHtml = `
                        <article class="score">
                            <h4 class="pos" style="background:url(${avatarUrl}) no-repeat center center; background-size: cover">
                                ${actualIndex}
                            </h4>
                            <h4 class="name-high">
                                ${score.username} 
                                <span class="moves">
                                    <span title="玩家步数">${score.player_steps}</span>-<span title="机器人步数">${score.robot_steps}</span>
                                </span>
                            </h4>
                            <p>
                                <span class="date-high">${score.created_at}</span>
                                <span class="time-high">${score.utime} 秒</span>
                            </p>
                        </article>
                    `;
                    $('.high').append(scoreHtml);
                });

                // 添加分页控件
                updatePagination(response.current_page, response.last_page);
            },
            error: function(xhr, status, error) {
                console.error('Error fetching high scores:', error);
            }
        });
        }

        function updatePagination(currentPage, lastPage) {
        let paginationHtml = '<div class="pagination">';
        
        // 上一页按钮
        paginationHtml += `
            <button class="page-btn" ${currentPage <= 1 ? 'disabled' : ''} data-page="${currentPage - 1}">
                <
            </button>
        `;

        // 页码按钮
        for (let i = 1; i <= lastPage; i++) {
            paginationHtml += `
                <button class="page-btn page-number ${i === currentPage ? 'active' : ''}" 
                        data-page="${i}">
                    ${i}
                </button>
            `;
        }

        // 下一页按钮
        paginationHtml += `
            <button class="page-btn" ${currentPage >= lastPage ? 'disabled' : ''} data-page="${currentPage + 1}">
                >
            </button>
        </div>`;

        // 移除旧的分页
        $('.pagination').remove();
        // 添加新的分页
        $('.high').after(paginationHtml);

        // 绑定点击事件
        $('.pagination .page-btn').not('[disabled]').on('click', function() {
            const page = $(this).data('page');
            updateHighScores(page);
        });
        }
        $(document).ready(function(){
        updateHighScores();
        });
</script>
</body>
</html>















