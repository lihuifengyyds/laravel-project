<div class="footer">
    <div class="container">内容管理系统</div>
</div>