<?php $__env->startSection('title', '内容列表'); ?>
<?php $__env->startSection('main'); ?>
    <div class="main-title">
        <h2>内容管理</h2>
    </div>
    <div class="main-section form-inline">
        <a href="<?php echo e(url('content/add')); ?>" class="btn btn-success">+ 新增</a>
        
        <select class="j-select form-control" style="main-width:120px;margin-left:8px">
            <option value="<?php echo e(url('content')); ?>" <?php echo e(request('id') == null ? 'selected' : ''); ?>>所有栏目</option>
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($v['level']): ?> 
                    <option value="<?php echo e(url('content', ['id' => $v['id']])); ?>" <?php echo e(request('id') == $v['id'] ? 'selected' : ''); ?>>
                        <small class="text-muted">--</small><?php echo e($v['name']); ?>

                    </option>
                <?php else: ?>
                    <option value="<?php echo e(url('content', ['id' => $v['id']])); ?>" <?php echo e(request('id') == $v['id'] ? 'selected' : ''); ?>>
                        <?php echo e($v['name']); ?>

                    </option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

     
    <div class="main-section">
        <form action="<?php echo e(url('category/sort')); ?>" class="j-form" method="post">
            <table class="table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                        <th width="75">序号</th>
                        <th>栏目</th>
                        <th>图片</th>
                        <th>标题</th>
                        <th>状态</th>
                        <th>创建时间</th>
                        <th width="100">操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <tr>
                            <td><?php echo e($v['id']); ?></td>
                            <td><?php echo e($v->category ? $v->category->name : '无分类'); ?></td>
                            <td><img <?php if($v->image): ?> src="/static/upload/<?php echo e($v->image); ?>" <?php else: ?> src="<?php echo e(asset('admin')); ?>/img/noimg.png" <?php endif; ?>
                                    width="50" height="50"></td>
                            <td><?php echo e($v->title); ?></td>
                            <td>
                                <?php if($v->status == 1): ?>
                                    默认
                                <?php else: ?>
                                    推荐
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($v->created_at); ?></td>
                            <td><a href="<?php echo e(url('content/edit', ['id' => $v->id])); ?>" style="margin-right:5px;">编辑</a>
                                <a href="<?php echo e(url('content/delete', ['id' => $v->id])); ?>" class="j-del text-danger">删除</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(empty($content)): ?>
                        <tr>
                            <td colspan="7" class="text-center">还没有添加内容</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php echo e(csrf_field()); ?>

        </form>
    </div>

    <script>
        main.menuActive('content');
        $('.j-del').click(function(){
            if(confirm('确定要删除吗？')){
                var data = {_token: '<?php echo e(csrf_token()); ?>'};
                main.ajaxPost({url:$(this).attr('href'),data:data},function(){
                    location.reload();
                });
            }
            return false;
        })
        $('.j-select').change(function(){
            window.location.href = $(this).val();
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>