<?php $__env->startSection('title', '栏目列表'); ?>
<?php $__env->startSection('main'); ?>
    <div class="main-title">
        <h2>栏目管理</h2>
    </div>
    <div class="main-section form-inline">
        <a href="<?php echo e(url('category/add')); ?>" class="btn btn-success">+ 新增</a>
    </div>
    <div class="main-section">
        <form action="<?php echo e(url('category/sort')); ?>" class="j-form" method="POST">
            
            <table class="table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                        <th width="75">序号</th>
                        <th>名称</th>
                        <th width="100">操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($category)): ?>
                        <tr>
                            <td colspan="3" class="text-center">没有添加栏目</td>
                        </tr>
                    <?php endif; ?>
                </tbody>

                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="j-pid-<?php echo e($v['pid']); ?>" <?php if($v['level']): ?> style="display:none" <?php endif; ?>>
                        <td><input type="text" class="form-control j-sort" maxlength="5" value="<?php echo e($v['sort']); ?>"
                                data-name="sort[<?php echo e($v['id']); ?>]" style="height:25px;font-size:12px;padding:0 5px;">
                        </td>
                        <td>
                            <?php if($v['level']): ?>
                                <small class="text-muted">|---</small><?php echo e($v['name']); ?>

                            <?php else: ?>
                                <a href="#" class="j-toggle" data-id="<?php echo e($v['id']); ?>">
                                    <?php if(!$v['isLeaf']): ?>
                                        <i class="fa fa-plus-square-o fa-fw"></i>
                                    <?php endif; ?>
                                    <?php echo e($v['name']); ?>

                                </a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(url('category/edit', ['id' => $v['id']])); ?>" style="margin-right:5px;">编辑</a>
                            <a href="<?php echo e(url('category/delete', ['id' => $v['id']])); ?>" class="j-del text-danger">删除</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php echo e(csrf_field()); ?>

            <input type="submit" value="改变排序" class="btn btn-primary">
        </form>
    </div>
<?php $__env->stopSection(); ?>


<script>
    main.menuActive('category');
    $(document).ready(function() {
        $('.j-sort').change(function() {
            $(this).attr('name', $(this).attr('data-name'));
        });

        $('.j-del').click(function(e) {
            e.preventDefault();
            var $this = $(this);
            var $row = $this.closest('tr');
            var categoryName = $row.find('td:nth-child(2)').text().trim();
            
            if (confirm('您确定要删除"' + categoryName + '"栏目吗？删除后不可恢复！')) {
                $.ajax({
                    url: $this.attr('href'),
                    type: 'GET',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.code === 1) {
                            alert(response.msg);
                            // 删除成功后移除该行
                            $row.fadeOut(300, function() {
                                $(this).remove();
                                // 检查是否还有其他栏目
                                if ($('tbody tr').length === 0) {
                                    // 如果没有栏目了，显示空提示
                                    $('tbody').html('<tr><td colspan="3" class="text-center">没有添加栏目</td></tr>');
                                }
                            });
                        } else {
                            alert(response.msg || '删除失败');
                        }
                    },
                    error: function(xhr) {
                        console.error('删除失败:', xhr.responseText);
                        alert('系统错误，请稍后重试');
                    }
                });
            }
        });

        // 切换子栏目显示/隐藏
        $('.j-toggle').click(function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            $('.j-pid-' + id).toggle();
            $(this).find('i').toggleClass('fa-plus-square-o fa-minus-square-o');
        });
    });
</script>

<?php echo $__env->make('admin/layouts/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>