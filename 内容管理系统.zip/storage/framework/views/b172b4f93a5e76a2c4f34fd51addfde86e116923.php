<?php $__env->startSection('title', '广告内容管理'); ?>
<?php $__env->startSection('main'); ?>
    <div class="main-title">
        <h2>
            <?php if(!empty($data)): ?>
                编辑
            <?php else: ?>
                添加
            <?php endif; ?> 广告
        </h2>
    </div>
    <div class="main-section form-inline">
        <a href="<?php echo e(route('advcontent.add')); ?>" class="btn btn-success">+ 新增</a>
    </div>
    <div class="main-section">
        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th width="75">序号</th>
                    <th>广告位名称</th>
                    <th>广告图片</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                
                <?php $__currentLoopData = $adv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="j-pid-<?php echo e($v['pid']); ?>">
                        <td><input type="text" value="<?php echo e($v->id); ?>" class="form-control j-sort" maxlength="5"
                                style="height:25px;font-size:12px;padding:0 5px;"></td>
                        <td><?php echo e($v->position->name); ?></td>
                        <td>
                            <?php $__currentLoopData = $v->path; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="/static/upload/<?php echo e($val); ?>" alt=""
                                    style="height: 40px;width:50px">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><a href="<?php echo e(url('advcontent/add', ['id' => $v->id])); ?>" style="margin-right:5px;">编辑</a>
                            <a href="<?php echo e(url('advcontent/delete', ['id' => $v->id])); ?>" class="j-del text-danger">删除</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(empty($adv)): ?>
                    <tr>
                        <td colspan="4" class="text-center">还没有添加广告内容</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <script>
        main.menuActive('advcontent');

        $('.j-del').click(function() {
            if (confirm('您确定要删除此项吗？')) {
                var data = {
                    _token: '<?php echo e(csrf_token()); ?>'
                };
                main.ajaxPost({
                    url: $(this).attr('href'),
                    data: data
                }, function() {
                    location.reload();
                });
            }
            return false;
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>