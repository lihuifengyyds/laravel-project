<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->make('common/static', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title>首页</title>
</head>
<body>
    <?php echo $__env->make('common.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="main">
        <div class="container">
            <div class="row mt-4">
                
                <div class="col-md-6 main-carousel">
                    <div class="carousel slide" id="carouselExampleCaptions" data-ride="carousel">
                        
                        <ol class="carousel-indicators">
                            <?php $__currentLoopData = $recommend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li data-target="#carouselExampleCaptions" data-slide-to="<?php echo e($k); ?>" class="<?php echo e($k==0 ? 'active' : ''); ?>"></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>
                        
                        <div class="carousel-inner">
                            <?php $__currentLoopData = $recommend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item <?php echo e($k==0 ? 'active' : ''); ?>">
                                    <img src="/static/upload/<?php echo e($con->image); ?>" class="d-block w-100" alt="<?php echo e($con->title); ?>">
                                    <a href="<?php echo e(url('detail',['id'=>$con->id])); ?>">
                                        <div class="carousel-caption d-none d-md-block">
                                            <h5><?php echo e($con->title); ?></h5>
                                            <p><?php echo str_limit($con->content,100); ?></p>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="row main-imgbox">
                        <?php $__currentLoopData = $adv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <a href="<?php echo e($adval['url']); ?>">
                                    <img src="/static/upload/<?php echo e($adval['image']); ?>" alt="Advertisement" class="img-fluid">
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-9">
                    <div class="row">
                        
                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 mb-4">
                                <div class="card main-card">
                                    <div class="card-header">
                                        <h2><?php echo e($value->name); ?></h2>
                                        <span class="float-right">
                                            <a href="<?php echo e(url('lists',['id' => $value->id])); ?>">[查看更多]</a>
                                        </span>
                                    </div>
                                    <?php $__currentLoopData = $value->content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="card-body">
                                            <div class="main-card-pic">
                                                <a href="#">
                                                    <img src="/static/upload/<?php echo e($val->image); ?>" alt="" class="img-fluid">
                                                    <span><i class="fa fa-search"></i></span>
                                                </a>
                                            </div>
                                            <div class="main-card-info">
                                                <span><i class="fa fa-calendar"></i>
                                                    <?php echo e(date('Y-m-d',strtotime($val->created_at))); ?>

                                                </span>
                                                <h3><a href="/article/<?php echo e($val->id); ?>"><?php echo e($val->title); ?></a></h3>
                                                <div class="main-card-desc">
                                                    <?php echo str_limit($val->content,100); ?>

                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                
                <?php echo $__env->make('common.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
    <?php echo $__env->make('common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>