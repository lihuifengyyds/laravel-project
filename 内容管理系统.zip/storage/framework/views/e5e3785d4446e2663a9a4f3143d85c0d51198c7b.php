<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" href="<?php echo e(asset('home')); ?>/common/twitter-bootstrap/4.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo e(asset('home')); ?>/common/font-awesome-4.2.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo e(asset('home')); ?>/css/main.css">
<script src="<?php echo e(asset('home')); ?>/common/jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo e(asset('home')); ?>/common/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
