<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('common/static', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title>列表页</title>
</head>
<body>
    <?php echo $__env->make('common/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="main">
        <div class="main-crumb">
            <div class="container">
                
                <nav aria-label="breadcrumb">
                    <?php echo Breadcrumbs::render('category', $id); ?>

                </nav>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <div class="row">
                    
                    <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mb-4">
                            <div class="card main-card">
                                <div class="main-card-pic">
                                    <a href="<?php echo e(url('detail',['id'=>$con->id])); ?>">
                                        <img src="<?php if($con->image): ?>/static/upload/<?php echo e($con->image); ?> <?php else: ?> <?php echo e(asset('admin')); ?>/img/noimg.png <?php endif; ?>" alt="">
                                        <span><i class="fa fa-search"></i></span>
                                    </a>
                                </div>
                                <div class="card-body">
                                    <div class="main-card-info">
                                        <span><i class="fa fa-calendar"></i>
                                        <?php echo e(date('Y-m-d',strtotime($con->created_at))); ?></span>
                                        <span><i class="fa fa-comments"><?php echo e($con->comment->count()); ?></i>
                                        0</span>
                                    </div>
                                    <h3><a href="<?php echo e(url('detail',['id'=>$con->id])); ?>"><?php echo e($con->title); ?></a></h3>
                                    <div class="main-card-desc">
                                        <?php echo str_limit($con->content,100); ?>

                                    </div>
                                </div>
                                <a href="<?php echo e(url('detail',['id'=>$con->id])); ?>" class="main-card-btn">阅读全文</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo e($content->links()); ?>

            </div>
            <div class="col-md-3">
                
                <?php echo $__env->make('common.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
    <?php echo $__env->make('common/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>