<?php $__env->startSection('title', '添加广告'); ?>
<?php $__env->startSection('main'); ?>
    <div class="main-title">
        <?php if(!empty($data)): ?> 编辑 <?php else: ?> 添加 <?php endif; ?> 广告位
    </div>
    <div class="main-section">
        <div style="width:543px;">
            <form action="<?php echo e(url('/adv/save')); ?>" method="POST">
                <div class="form-group row">
                    <div class="col-sm-3 col-form-label">广告位名称</div>
                    <div class="col-sm-9">
                        <input type="text" name="name" <?php if(isset($data['name'])): ?> value="<?php echo e($data['name']); ?>" <?php endif; ?> class="form-control" style="width:200px;">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <?php echo e(csrf_field()); ?>

                        <?php if(isset($data['id'])): ?>
                        <input type="hidden" name="id" value="<?php echo e($data['id']); ?>">
                        <?php endif; ?>
                        <button type="submit" class="btn btn-primary mr-2">提交表单</button>
                        <a href="<?php echo e(url('adv')); ?>" class="btn btn-secondary">返回列表</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script>
        // main.menuActive('adv');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>