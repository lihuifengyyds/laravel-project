<?php $__env->startSection('title', '栏目列表'); ?>
<?php $__env->startSection('main'); ?>
<div class="main-title"><h2>编辑栏目</h2></div>
<div class="main-section">
    <div style="width: 543px">
        
        <form action="<?php echo e(url('/category/save')); ?>" method="POST">
            <div class="form-group row">
                <label for="" class="col-sm-2 col-form-label">序号</label>
                <div class="col-sm-10">
                    <input type="number" name="sort" class="form-control" value="<?php echo e($data->sort); ?>" style="width: 80px;">
                </div>
            </div>
            <div class="form-group row">
                <label for="" class="col-sm-2 col-form-label">上级栏目</label>
                <div class="col-sm-10">
                    <select name="pid" class="form-control" style="width: 200px;">
                        <option value="0">---</option>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($v->id); ?>" <?php if($data['pid'] == $v['id']): ?> selected <?php endif; ?>><?php echo e($v->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label for="" class="col-sm-2 col-form-label">名称</label>
                <div class="col-sm-10">
                    <input type="text" name="name" class="form-control" value="<?php echo e($data->name); ?>" style="width: 200px;">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-10">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="id" value="<?php echo e($id); ?>">  
                    <button type="submit" class="btn btn-primary mr-2">提交表单</button>
                    <a href="<?php echo e(url('category')); ?>" class="btn btn-secondary">返回列表</a>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    main.menuActive('category')
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layouts/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>