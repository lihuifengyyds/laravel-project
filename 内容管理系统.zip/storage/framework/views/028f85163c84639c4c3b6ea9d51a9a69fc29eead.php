<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('common/static', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title>详细页</title>
</head>

<body>
    <?php echo $__env->make('common/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="main">
        <div class="main-crumb">
            <div class="container">
                
                <nav aria-label="breadcrumb">
                    <?php echo Breadcrumbs::render('detail', ['id' => $id, 'cid' => $cid]); ?>

                </nav>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    
                    <article class="main-article">
                        <header>
                            <h1><?php echo e($content->title); ?></h1>
                            <div>发表于<?php echo e(date('Y-m-d', strtotime($content->created_at))); ?></div>
                        </header>
                        <div class="main-article-content">
                            <p>
                                <img src="/static/upload/<?php echo e($content->image); ?>" class="img-fluid">
                            </p>
                            <p><?php echo $content->content; ?></p>
                        </div>
                        
                        <?php if(session()->has('users')): ?>
                            <div class="main-article-like">
                                <span>
                                    <i class="fa fa-thumbs-up" aria-hidden="true"><?php echo e($count); ?></i>
                                </span>
                            </div>
                        <?php endif; ?>
                    </article>
                    <div class="main-comment">
                        
                        <?php if(!$comments->isEmpty()): ?>
                            <div class="main-comment-header">
                                <span id="count"><?php echo e($comments->count()); ?></span>条评论
                            </div>
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="main-comment-item">
                                <div class="main-comment-name"><?php echo e($val->user->name); ?></div>
                                <div class="main-comment-date">
                                    <?php echo e(date('Y-m-d',strtotime($val->created_at))); ?></div>
                                    <div class="main-comment-content">
                                        <?php echo e($val->content); ?>

                                    </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    
                    <div class="main-reply">
                        <?php if(session()->has('users')): ?> 
                            <div class="main-reply-header">发表评论</div>
                            <div class="main-reply-title">评论内容</div>
                            <div>
                                <textarea name="content" id="content" cols="30" rows="8"></textarea>
                            </div>
                            <div>
                                <input type="hidden" id="c_id" value="<?php echo e($id); ?>">
                                <input type="button" value="提交评论" id="publish">
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-3">
                    
                    <?php echo $__env->make('common.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('common/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>

<script>
    $('.fa-thumbs-up').on('click', function() {
        var $this = $(this);
        $.get("<?php echo e(url('like', $id)); ?>", {}, function(result) {
            if (result.status === '1') {
                $this.text(result.count);
                alert(result.msg);
            } else {
                alert(result.msg);
            }
        }).fail(function() {
            alert('请求失败，请检查网络连接。');
        });
    });

    $(document).ready(function(){
        $('#publish').on('click', function(){
            var content = $('#content').val();
            if (!content.trim()) {
                alert('请输入评论内容');
                return;
            }
            
            var data = {
                'cid': $('#c_id').val(),
                'content': content
            };
            
            $.get("<?php echo e(url('comment')); ?>", data, function(result){
                if (result.status === '1') {
                    var data = result.data;
                    var html = '<div class="main-comment-item">' +
                        '<div class="main-comment-name">' + data.user + '</div>' +
                        '<div class="main-comment-date">' + data.created_time + '</div>' +
                        '<div class="main-comment-content">' + data.content + '</div>' +
                        '</div>';
                    
                    if ($(".main-comment-header").length === 0) {
                        $(".main-comment").prepend('<div class="main-comment-header"><span id="count">1</span>条评论</div>');
                    }
                    
                    $(".main-comment-header").after(html);
                    $('#count').text(data.count);
                    $('#content').val(''); // 清空输入框
                    alert(result.msg);
                } else {
                    alert(result.msg || '评论失败');
                }
            }).fail(function() {
                alert('请求失败，请检查网络连接');
            });
        });
    });
</script>
