<?php $__env->startSection('title', '添加项目'); ?>
<?php $__env->startSection('main'); ?>
    <div class="main-title">
        <h2>添加栏目</h2>
    </div>
    <div class="main-section">
        <div style="width:543px">
            
            <form action="<?php echo e(url('/category/save')); ?>" method="POST">
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">序号</label>
                    <div class="col-sm-10">
                        <input type="number" class="form-control" name="sort" value="0" style="width:80px;">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">上级目录</label>
                    <div class="col-sm-10">
                        <select name="pid" class="form-control" style="width:200px;">
                            <option value="0">---</option>
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($v->id); ?>"><?php echo e($v->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-2 col-form-label">名称</label>
                    <div class="col-sm-10">
                        <input type="text" name="name" class="form-control" style="width:200px;">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <?php echo e(csrf_field()); ?> 
                        <button type="submit" class="btn btn-primary mr-2">提交表单</button>
                        <a href="<?php echo e(url('category')); ?>" class="btn btn-secondary">返回列表</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <script>
        main.menuActive('addcategory');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>