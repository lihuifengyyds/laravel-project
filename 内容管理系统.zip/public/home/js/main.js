$(function() {
    //$('.header .dropdown-toggle').hover(function() {
    //    $(this).next().dropdown('show');
    //}, function() {
    //    $(this).next().dropdown('hide');
    //});
    //$('.header .dropdown-menu').hover(function() {
    //    $(this).dropdown('show');
    //}, function() {
    //    $(this).dropdown('hide');
    //});
});